const fs = require('fs');
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const basename = path.basename(__filename);
const db = {};

// Load all models dynamically
fs.readdirSync(__dirname)
  .filter(file => file !== basename && file.endsWith('.js'))
  .forEach(file => {
    const model = require(path.join(__dirname, file))(sequelize, DataTypes);
    db[model.name] = model;
  });

// Run associate() methods
Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

// Manual associations (if needed)
if (db.Customer && db.Item && db.Purchase) {
  db.Customer.hasMany(db.Purchase, { foreignKey: 'customerId' });
  db.Purchase.belongsTo(db.Customer, { foreignKey: 'customerId' });

  // db.Item.hasMany(db.Purchase, { foreignKey: 'itemId' });
  // db.Purchase.belongsTo(db.Item, { foreignKey: 'itemId' });
}

if (db.Pricing && db.Shop && db.Item) {
  db.Shop.hasMany(db.Pricing, { foreignKey: "shopId" });
  db.Pricing.belongsTo(db.Shop, { foreignKey: "shopId" });

  db.Item.hasMany(db.Pricing, { foreignKey: "itemId" });
  db.Pricing.belongsTo(db.Item, { foreignKey: "itemId" });
}

if (db.InventoryTransfer && db.Shop && db.Item) {
  // From and To shops (2 associations to the same model)
 db.Shop.hasMany(db.InventoryTransfer, { foreignKey: "fromShopId", as: "TransfersFrom" });
db.Shop.hasMany(db.InventoryTransfer, { foreignKey: "toShopId", as: "TransfersTo" });

db.InventoryTransfer.belongsTo(db.Shop, { foreignKey: "fromShopId", as: "FromShop" });
db.InventoryTransfer.belongsTo(db.Shop, { foreignKey: "toShopId", as: "ToShop" });
  // Item association
  db.Item.hasMany(db.InventoryTransfer, { foreignKey: "itemId" });
  db.InventoryTransfer.belongsTo(db.Item, { foreignKey: "itemId" });
}


if (db.Shop && db.ShopInventory) {
  db.Shop.hasMany(db.ShopInventory, { foreignKey: 'shopId' });
  db.ShopInventory.belongsTo(db.Shop, { foreignKey: 'shopId' });
}

if (db.Purchase && db.User) {
  db.User.hasMany(db.Purchase, { foreignKey: 'userId' });
  db.Purchase.belongsTo(db.User, { foreignKey: 'userId' });
}

if (db.Item && db.ShopInventory) {
  db.Item.hasMany(db.ShopInventory, { foreignKey: 'itemId' });
  db.ShopInventory.belongsTo(db.Item, { foreignKey: 'itemId' });
}

if (db.Customer && db.Sales) {
  db.Customer.hasMany(db.Sales, { foreignKey: 'customerId' });
  db.Sales.belongsTo(db.Customer, { foreignKey: 'customerId', as: 'customer' });
}

// if (db.Item && db.Sales) {
//   db.Item.hasMany(db.Sales, { foreignKey: 'itemId' });
//   db.Sales.belongsTo(db.Item, { foreignKey: 'itemId', as: 'item' });
// }

if (db.Shop && db.Sales) {
  db.Shop.hasMany(db.Sales, { foreignKey: 'shopId' });
  db.Sales.belongsTo(db.Shop, { foreignKey: 'shopId', as: 'shop' });
}

if (db.User && db.Sales) {
  db.User.hasMany(db.Sales, { foreignKey: 'userId' });
  db.Sales.belongsTo(db.User, { foreignKey: 'userId', as: 'user' });
}
if (db.Shop && db.Expense) {
  db.Shop.hasMany(db.Expense, { foreignKey: 'shopId' });
  db.Expense.belongsTo(db.Shop, { foreignKey: 'shopId', as: 'shop' });
}
if (db.Damage && db.Item && db.Shop) {
  db.Item.hasMany(db.Damage, { foreignKey: 'itemId' });
  db.Damage.belongsTo(db.Item, { foreignKey: 'itemId', as: 'item' });
  db.Shop.hasMany(db.Damage, { foreignKey: 'shopId' });
  db.Damage.belongsTo(db.Shop, { foreignKey: 'shopId', as: 'shop' });
}
if (db.PaymentMethod && db.Sales) {
  db.PaymentMethod.hasMany(db.Sales, { foreignKey: 'paymentMethodId' });
  db.Sales.belongsTo(db.PaymentMethod, { foreignKey: 'paymentMethodId', as: 'paymentMethod' });
}



db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
